<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "finalproject");
$query    = "SELECT * FROM `users`";
$result = mysqli_query($conn, $query);
if (isset($_REQUEST['varname'])) {
	$reciever_id= $_REQUEST['varname'];
	$_SESSION["recieversid"] = $_REQUEST['varname'];
}
else {
	$reciever_id=$_SESSION["recieversid"];
}
$sender_id=$_SESSION["id"];

$recieverinfo = mysqli_query($conn,"SELECT * FROM users_info WHERE user_id = '$reciever_id'");
$senderinfo = mysqli_query($conn,"SELECT * FROM users_info WHERE user_id = '$sender_id'");
$recieverinfo = mysqli_fetch_array($recieverinfo);
$senderinfo = mysqli_fetch_array($senderinfo);
$recieverinfomain = mysqli_query($conn,"SELECT * FROM users WHERE user_id = '$reciever_id'");
$senderinfomain = mysqli_query($conn,"SELECT * FROM users WHERE user_id = '$sender_id'");
$recieverinfomain = mysqli_fetch_array($recieverinfomain);
$senderinfomain = mysqli_fetch_array($senderinfomain);
?>
<?php 
if (isset($_POST["submitmsg"])) {
		$message = $_POST['usermsg'];
		if ($message!="") {
		$writemessage = "INSERT INTO personal_chat (sender_id, reciever_id, message) VALUES ('$sender_id', '$reciever_id', '$message')";
          mysqli_real_query($conn, $writemessage);
          header("Refresh:0");
		}

}
?>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="text/css" href="../photos/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="jquery.loading.js"></script>
    <head>
    	<style type="text/css">
            body {
      background-image: url('../images/img-02.jpg');
      background-repeat: no-repeat;
      background-size: cover;
    
    }
    		.recentbutton {
    			color: white;
    			background-color: black;
    			border: 0;
    		}
    		.recentbutton:hover {
    			color: orange;
    		}
    		.submission {
    			width: 20px;
    			background-image: url(https://www.iconpacks.net/icons/2/free-paper-plane-icon-2563-thumb.png);
				background-repeat: no-repeat;
				background-position: right;
				padding-left: 20px;
    		}
    		html {
    			overflow: scroll;
   				overflow-x: hidden;
    		}
    		body {
    			background-color: white;

    		}
    		.main {
    			background-color: #000000;
    			overflow: hidden;
    		}
    		.chatboxparent {
    			overflow: hidden;
    		}
    		.chatbox::-webkit-scrollbar {
			  display: none;
			}
    		.chatbox {
    			overflow: scroll	;
    			height: 500px;
    			margin-top: 25px;
      			--stripe: #FFFBEC;
  				--bg: #FCF8D7;
				  background: linear-gradient(135deg, var(--bg) 25%, transparent 25%) -50px 0,
				    linear-gradient(225deg, var(--bg) 25%, transparent 25%) -50px 0,
				    linear-gradient(315deg, var(--bg) 25%, transparent 25%),
				    linear-gradient(45deg, var(--bg) 25%, transparent 25%);
				  background-size: 100px 100px;
				  background-color: var(--stripe);
    		}
			.messageboxer {
				--stripe: white;
  				--bg: #F9F9F9;
				  background: linear-gradient(90deg, var(--bg) 25%, transparent 25%) -50px 0,
				    linear-gradient(225deg, var(--bg) 25%, transparent 25%) -50px 0,
				    linear-gradient(315deg, var(--bg) 25%, transparent 25%),
				    linear-gradient(45deg, var(--bg) 25%, transparent 25%);
				  background-size: 100px 100px;
				  background-color: var(--stripe);
			}
    		.messagebox{
		      margin: 10px;
		      text-align: center;
		      line-height: 30px;
		      font-size: 20px;

		    }	
		    .sender {
			  background-color: lightgreen;
			  text-align: left;
			  border-top-left-radius: 20px;
			  border-bottom-left-radius: 20px;
			  border-bottom-right-radius: 20px;
			}
			.reciever {
			  background-color: lightblue;
			  text-align: left;
			  border-top-right-radius: 20px;
			  border-bottom-left-radius: 20px;
			  border-bottom-right-radius: 20px;
			}
			.arrow {
				color: white;
			  display: inline-block;
			  width: 15px;
			  height: 15px;
			  border-top: 2px solid #FFFFFF;
			  border-right: 2px solid #FFFFFF;
			}
			.arrow-left {
			  transform: rotate(-135deg);
			}
			.arrow:hover {
				background-color: orange;
			}
			.imagesrc {
				width: 100%;
			}
    	</style>



    	<style type="text/css">
    .topnav {
  background-color: black;
  overflow: hidden;
}
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
.topnav a:hover {
  background-color: orange;
  color: black;
}
@media (min-width: 500px) and (max-width: 960px) {
        .imagesrc {
          display: none;
        }
        .messagecontent {
        	width: 30%;
        }
        .sender {
        	width: 30%;
        	margin-left: 70%;
        }
        .reciever {
        	width: 30%;
        }
        .sendingcontent {
        	margin-left: 40%;
        }
 }

</style>



<script type="text/javascript">

window.onload=function scrolling() {
     var objDiv = document.getElementById("chatbox");
     objDiv.scrollTop = 999999999999999;
     var scrollPos = $('#chatbox').scrollTop();
}

var scrollMax;

 setInterval(function () {
            var scrollTarget = $('#chatbox');
            var loadTarget = $('#chatboxparent');
            var pos = scrollTarget.scrollTop();
            loadTarget.load('messagepage.php #chatbox', function() {
            	var trueDivHeight = $('#chatbox')[0].scrollHeight;
				var divHeight = $('#chatbox').height();
				scrollMax = trueDivHeight - divHeight;
				// alert(scrollMax-pos);
                $('#chatbox').scrollTop(pos);
                if (scrollMax-pos<70) {
                	$('#chatbox').scrollTop(scrollMax);
                } else if (scrollMax-pos>100) {
                	<?php
                	$recentMessages=1;
                	?>

                }
            });
},2000);

 function scrollingrecent() {
     var objDiv = document.getElementById("chatbox");
     $("html, #chatbox").animate({ scrollTop: "9999" }, 1000);
}


// $('#chatbox').scroll(function() {
//   if ($('#chatbox').html().length) {
//     scrollPos = $('#chatbox').scrollTop();
//   }
// });

// function loading() {
// 	$("#chatbox").load("/messagepage.php", function(){
// 		var objDiv = document.getElementById("chatbox");
// 		objDiv.scrollTop = scrollPos;
// });




// // 	$('#chatbox').load('/messagepage.php', function() {

// //   $('#chatbox').scrollTop(scrollPos);
// // });
// }

// 	$(document).ready(function(){
//         myVar = setInterval("loading()", 2000);
//     });


// function loading() {
//     // $("#chatbox").load("messagepage.php #chatbox");
//     	var objChat = document.getElementById("chatbox");
// 	lastScrollPos = $("#chatbox").scrollTop();	
// 	 objChat.scrollTop = lastScrollPos;
// }






</script>
        <meta charset="utf-8" />
        <title>Chat with  <?php echo $recieverinfo['name']; ?> </title>
        <link rel="stylesheet" href="style.css" />
    </head>
    <body >
<div class="topnav">
   <a href="userpage.php" class="backbutton"><span class="arrow arrow-left"></span>Back</a>
</div>

    	<div class="row">
    <div class="col-lg-2">
    	
    </div>
<div id="main" class="main col-lg-8" id="wrapper">
<span style="color: white; font-weight: 5px;">Chatting with <?php echo $recieverinfo['name']; ?></span>
<span style="float: right; color: white"><button class="recentbutton" onclick="scrollingrecent()">show recent messages</button></span>
    <form method="POST" name="message" action="">
    	<div id = "chatboxparent">
        <div id="chatbox" class="chatbox">
    	<?php  
    	$counter = 0;
    	$firsttimechecker =0;
    	$quesryy="SELECT * FROM personal_chat WHERE (sender_id = '$sender_id' && reciever_id = '$reciever_id') || (sender_id = '$reciever_id' && reciever_id = '$sender_id')";
    	$querymsg=mysqli_query($conn,$quesryy);
    	if (!isset($querymsg)) {
    		echo "NO HISTORY";
    	} else 
    	{

    	while($rowmsg=mysqli_fetch_array($querymsg)){
    		if ($rowmsg['sender_id']==$sender_id) {
    			if ($firsttimechecker==0) {
    				$counter=1;
    				$firsttimechecker=1;
    			}

    		?>

    		<div class="row messagebox">
    				<div class="col-lg-7">
    					
    				</div>
    			    <div class="sender col-lg-4">
    			    		<span id="" class="messagecontent" src=""><?php echo $rowmsg['message'];?></span>
    				</div>

    				<div class="col-lg-1">
    					<?php
    					if ($counter==1 OR $counter==-2) {
    						?>
    						<img class="imagesrc"  src="<?php echo  '../photos/'. $senderinfomain['ava']; ?>">
    						<?php
    						$counter=2;
    					}
    					?>

				    </div>
    		</div>
    		<?php
    		} else {
    			if ($firsttimechecker==0) {
    				$counter=2;
    				$firsttimechecker=1;
    			}
    			?>
    		<div class="row messagebox">
    			     <div class="col-lg-1">
    			     	<?php
    					if ($counter==-1 OR $counter==2) {
    						?>
    						<img class="imagesrc"  src="<?php echo  '../photos/'. $recieverinfomain['ava']; ?>">
    						<?php
    						$counter=-2;
    					}
    					?>
				     </div>
    			    <div class="reciever col-lg-4">
    			    		<span id="" class="messagecontent" src=""><?php echo $rowmsg['message'];?></span>
    				</div>
    				 <div class="col-lg-7">
    					
    				</div>
    		  	</div>
    			<?php
    		}
    		?>
    		<?php
    		}
    	}
    	?>
    	</div>
    	</div>
    <div class="row">
    	<div class="col-lg-6">
    		
    	</div>
    	<div class="col-lg-6 sendingcontent">
    	<input style="margin: right;" class="messageboxer" name="usermsg" placeholder="write your message here" type="text" id="usermsg" size="53" />
        <input style="margin: right; width: 50px; margin-top: 5px;" class="submission"  name="submitmsg" type="submit"  id="submitmsg" value="->" />
    	</div>

    </form>
    </div>
</div>
</div>
</body>