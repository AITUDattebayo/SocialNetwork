<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "finalproject");
$queryaaa    = "SELECT * FROM `users`";
$resultaaa = mysqli_query($conn, $queryaaa);

?>
<html>
<head>
  <style type="text/css">
    html {
      background-image: url('../images/img-02.jpg');
    }
    .topnav {
  background-color: #0C247D;
  overflow: hidden;
}
.middle {
  border-radius: 8px;
background-opacity: 30%;
}
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
.topnav a:hover {
  background-color: lightgray;
  color: black;
}


#wrapper,
  #loginform {
    margin: 0 auto;
    padding-bottom: 10px;
    background: white;
    width: 600px;
    max-width: 100%;
    border: 1px solid black;
    border-radius: 4px;
  }
   
  #chatbox {
    text-align: left;
    margin: 0 auto;
    margin-bottom: 25px;
    padding: 10px;
    background: #fff;
    height: 300px;
    width: 100%;
    border: 1px solid #a7a7a7;
    overflow: auto;
    border-radius: 4px;
    border-bottom: 4px solid #a7a7a7;
  }
   
  #usermsg {
    flex: 1;
    border-radius: 4px;
    border: 1px solid #ff9800;
  }
   
  #name {
    border-radius: 4px;
    border: 1px solid #ff9800;
    padding: 2px 8px;
  }
   
  #submitmsg,
  #enter{
    background: #ff9800;
    border: 2px solid #e65100;
    color: white;
    padding: 4px 10px;
    font-weight: bold;
    border-radius: 4px;
  }
   
  .error {
    color: #ff0000;
  }
   
  #menu {
    padding: 15px 25px;
    display: flex;
  }
   
  #menu p.welcome {
    flex: 1;
  }
   
  a#exit {
    color: white;
    background: #c62828;
    padding: 4px 8px;
    border-radius: 4px;
    font-weight: bold;
  }
   
  .msgln {
    margin: 0 0 5px 0;
  }
   
  .msgln span.left-info {
    color: orangered;
  }
   
  .msgln span.chat-time {
    color: #666;
    font-size: 60%;
    vertical-align: super;
  }
   
  .msgln b.user-name, .msgln b.user-name-left {
    font-weight: bold;
    background: #546e7a;
    color: white;
    padding: 2px 4px;
    font-size: 90%;
    border-radius: 4px;
    margin: 0 5px 0 0;
  }
   
  .msgln b.user-name-left {
    background: orangered;
  }

  </style>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="text/css" href="../photos/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link rel="stylesheet" href="../css/books.css">
<title>User Login</title>
</head>
<body style="color: gray;">
<?php
if (!isset($_SESSION["name"])) {
  header("Location:userpage.php");
}
if($_SESSION["name"]) {
$id_of_user = $_SESSION["id"];

$userinfoa = mysqli_query($conn,"SELECT * FROM users WHERE user_id = '$id_of_user'");
$userinfo = mysqli_fetch_array($userinfoa);
$userdetaila = mysqli_query($conn,"SELECT * FROM users_info WHERE user_id = '$id_of_user'");
$userdetail = mysqli_fetch_array($userdetaila);
$avatar = $userinfo['ava'];
$users_name = $userinfo['user_name'];
?>

<?php
if (isset($_POST['log'])) {

$newava = $_FILES['file']['name'];

$updateavatar = "UPDATE users SET ava='$newava' WHERE user_id='$id_of_user'"; 
mysqli_query($conn, $updateavatar);
header("Refresh:0");
}

if (isset($_POST['changeinfo'])) {

$newname = $_REQUEST['new_name'];
$newsurname = $_REQUEST['new_surname'];
$newage = $_REQUEST['new_age'];
$newnation = $_REQUEST['new_nationality'];
$newcountry = $_REQUEST['new_country'];
$neweducation = $_REQUEST['new_education'];
$newmarital = $_REQUEST['new_marital'];
$newinterests = $_REQUEST['new_interests'];
$newstatus = $_REQUEST['new_status'];
$current_password = $_REQUEST['current_password'];

$updatename = "UPDATE users SET user_name='$newname' WHERE user_id='$id_of_user'"; 
$updatedetails = "UPDATE users_info SET name = '$newname', surname='$newsurname', age='$newage', nationality='$newnation', country='$newcountry', education='$neweducation', marital_status='$newmarital', interests='$newinterests', extra='$newstatus' WHERE user_id='$id_of_user'";
 $query123    = "SELECT * FROM `users` WHERE user_id='$id_of_user' AND password='$current_password'";
        $result123 = mysqli_query($conn, $query123);
        $row123  = mysqli_fetch_array($result123);
        if(is_array($row123)) {
          mysqli_query($conn, $updatename);
          mysqli_query($conn, $updatedetails);
          header("Refresh:0");
        } else {
          echo '<script>alert("Incorrect Password")</script>'; 
        }


}
if (isset($_POST['changepassword'])) {

$newpassword = $_REQUEST['new_password'];
$current_password_for_password = $_REQUEST['current_password_for_password'];

$updatename = "UPDATE users SET password='$newpassword' WHERE user_id='$id_of_user'"; 
 $query123    = "SELECT * FROM `users` WHERE user_id='$id_of_user' AND password='$current_password_for_password'";
        $result123 = mysqli_query($conn, $query123);
        $row123  = mysqli_fetch_array($result123);
        if(is_array($row123)) {
          mysqli_query($conn, $updatename);
          header("Refresh:0");
        } else {
          echo '<script>alert("Incorrect Password")</script>'; 
        }


}

?> 
<script language="JavaScript" type="text/javascript">

function changeinformation(showhide){
if(showhide == "show"){
    document.getElementById('informationchangepop').style.visibility="visible";
    document.getElementById('informationchangepop').style.display="block";
    document.getElementById('labelforinfohid').style.visibility="hidden";
}else if(showhide == "hide"){
    document.getElementById('informationchangepop').style.visibility="hidden"; 
    document.getElementById('informationchangepop').style.display="none";
    document.getElementById('labelforinfohid').style.visibility="visible";
}
}

function changepassword(showhide){
if(showhide == "show"){
    document.getElementById('passwordchangepop').style.visibility="visible";
    document.getElementById('passwordchangepop').style.display="block";
    document.getElementById('labelforpasshid').style.visibility="hidden";
}else if(showhide == "hide"){
    document.getElementById('passwordchangepop').style.visibility="hidden"; 
    document.getElementById('passwordchangepop').style.display="none";
    document.getElementById('labelforpasshid').style.visibility="visible";
}
}
</script>
<div class="topnav">
   <a href="logout.php" tite="Logout"> Click here to Logout.</a>
</div>

<div  class="middle" style="padding: 1%; background-image: url('wall.jpg');">
<div class="row col-lg-12">
<div class="row col-lg-4">
<form method="POST" enctype="multipart/form-data">
      <div>
      	<div class="col-lg-3">
      	<img class="imagesrc" width="400%" src="<?php echo  '../photos/'. $userinfo['ava']; ?>">
      	<input style="margin-top: 10px;" name="file" type="file" required>
        <input style="margin-top: 10px;" type="submit" name="log">
      	</div>
      	
      </div>
      <br>
</form>
</div>
<div class="row col-lg-4" >
<a href="javascript:changeinformation('show');" id="labelforinfohid">Change information</a>
<div id="informationchangepop" style="visibility: hidden; display: none;">
<form name="changeinformation" method="POST">
        <div   class="row col-lg-12">
        <div class="col-lg-12">
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Name</label><input type="" name="new_name" required="" value="<?php echo  $userinfo['user_name']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Surname</label><input type="" name="new_surname" required="" value="<?php echo  $userdetail['surname']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Age</label><input type="number" name="new_age" required="" value="<?php echo  $userdetail['age']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Nationality</label><input type="" name="new_nationality" required="" value="<?php echo  $userdetail['nationality']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Country</label><input type="" name="new_country" required="" value="<?php echo  $userdetail['country']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Education</label><input type="" name="new_education" required="" value="<?php echo  $userdetail['education']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Marital</label><input type="" name="new_marital" required="" value="<?php echo  $userdetail['marital_status']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Interests</label><input type="" name="new_interests" required="" value="<?php echo  $userdetail['interests']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Status</label><input type="" name="new_status" required="" value="<?php echo  $userdetail['extra']; ?>">
          <br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Current Password</label><input required="" type="password" name="current_password">
            <br>
            <input type="submit" name="changeinfo" style="margin-top: 10px;">
          <a href="javascript:changeinformation('hide');" style="text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000; margin-top: 5px;"><i>CLOSE</i></a>
          <br><br>
        </div>
      </div>
</form>
</div>
</div>

<div class="row col-lg-4">
<a href="javascript:changepassword('show');" id="labelforpasshid">Change password</a>
<div id="passwordchangepop" style="visibility: hidden; display: none;">
<form method="POST">
        <div class="row col-lg-12">
        <div class="col-lg-12">
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your New Password</label><input type="" name="new_password"><br>
          <label style="color: lightgreen; text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000;">Your Current Password</label><input required="" type="password" name="current_password_for_password"><br>
          <input type="submit" name="changepassword" style="margin-top: 10px;">
          <a href="javascript:changepassword('hide');" style="text-shadow:-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000; margin-top: 5px;"><i>CLOSE</i></a>
        </div>
      </div>
    </div>
</form>
</div>
</div>


              <script>
              function startchating(recievers_id) {
                <?php
                $_SESSION["sender_id"] = $_SESSION["id"];
                $_SESSION["reciever_id"] = recievers_id;
                header("Location:messagepage.php");
                ?>
              }
              </script>



<?php  
$k = isset($_GET['k']) ? $_GET['k'] : '';
$kk = isset($_GET['kk']) ? $_GET['kk'] : '';
if (!$k=="") {
$search_string = "SELECT * FROM users_info WHERE ";
$display_words = "";
          

  $keywords = explode(' ', $k);   
  $kkeywords = explode(' ', $kk);
foreach ($keywords as $word){
  $search_string .= "name LIKE '%".$word."%' OR ";
  // if (!($kkeywords=="")) {
  // $search_string .= "age > '".$kkeywords."' OR";
  // }
  $display_words .= $word.' ';

}
$search_string = substr($search_string, 0, strlen($search_string)-4);
$display_words = substr($display_words, 0, strlen($display_words)-1);






$queryaaaaaa = mysqli_query($conn, $search_string);
$result_count = mysqli_num_rows($queryaaaaaa);

echo '<div class="right"><b><u>'.number_format($result_count).'</u></b> results found</div>';
echo 'Your search for <i>"'.$display_words.'"</i><hr />';

if ($result_count > 0){
  echo '<table class="search">';
  ?>
  <tr>
            <div class="row" style="color: green;">

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src="">Name</span>
              </div>

              <div class="col-lg-2" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src="">Surname</span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src="">Age</span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src="">Marital</span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
                Status
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
                Contact
              </div>
              
            </div>
          </tr>

  <?php
  while ($rowaaa = mysqli_fetch_array($queryaaaaaa)){
   ?>
          <tr>
            <div class="row" style="color: green;">


              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src=""><?php echo $rowaaa['name'];?></span>
              </div>

              <div class="col-lg-2" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src=""><?php echo $rowaaa['surname'];?></span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src=""><?php echo $rowaaa['age'];?></span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src=""><?php echo $rowaaa['marital_status'];?></span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <span id="" src=""><?php echo $rowaaa['extra'];?></span>
              </div>

              <div class="col-lg-1" style="border:solid 1px green;  background-color: lightblue;">
              <?php 
              if ($rowaaa['user_id']==$userinfo['user_id']) {
              echo '<span id="" src="">Its you</span>';
              }
              else 
              {
              ?>
              <a href="messagepage.php?varname=<?php echo $rowaaa['user_id'] ?>">Write</a>
                <?php
              }
                          ?>
            </div>
            </div>
          </tr>
        <?php
  }
  echo '</table>';
}
else
  echo 'There were no results for your search. Try searching for something else.';
}
?>
<div class="row">
<div class="container col-lg-6 b-popup-content" style="">
  <form action="userpage.php" method="GET" name="">
  <table>
    <tr>
      <td>
        <input type="text" name="k" value="<?php echo isset($_GET['k']) ? $_GET['k'] : ''; ?>" placeholder="Enter your search keywords" />
      </td>
      <td>
        <input style="width: 75px;" type="number" name="kk" value="<?php echo isset($_GET['kk']) ? $_GET['kk'] : ''; ?>" placeholder="Min Age" />
      </td>
      <td>
        <input type="submit" name="" value="Search" />
      </td>
    </tr>
  </table>
</form>
</div>


</div>



</div>




      


<?php

}
else header("Location:userpage.php");
?>
</body>
</html> -->